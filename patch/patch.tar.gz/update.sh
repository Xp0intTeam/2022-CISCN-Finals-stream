#!/bin/bash

cp stream /home/ctf/stream

